# Time    : 2023/6/1 11:23:23
# Author  : dabinhuang
# File    : intran.py
# Version : python3.7.5



import  random

def int11():

    return "".join(random.choice("0123456789") for i in range(10))
